package Wallet;

public interface Wallet {
    double getSaldo();
    void abonar(double abono);
    void retirar(double retiro);
    double convertir();
}