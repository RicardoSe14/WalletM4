package Wallet;

import java.util.Scanner;


public class MyWallet implements Wallet {
    private double saldo;

    public MyWallet(double saldoInicial) {
        this.saldo = saldoInicial;
    }

    @Override
    public double getSaldo() {
        return saldo;
    }

    @Override
    public void abonar(double abono) {
        saldo += abono;
        System.out.println("Se ha abonado $" + abono + " correctamente.");
        System.out.println("Su nuevo saldo es $" + saldo);
    }

    @Override
    public void retirar(double retiro) {
        if (retiro > saldo) {
            System.out.println("Saldo insuficiente.");
        } else {
            saldo -= retiro;
            System.out.println("Se han retirado $" + retiro + " correctamente.");
            System.out.println("Su nuevo saldo es $" + saldo);
        }
    }

    @Override
    public double convertir() {
        double tasa = 947;
        double saldoUSD = saldo / tasa;
        System.out.println("Su saldo en dólares es: $" + saldoUSD);
        return saldoUSD;
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        Wallet myWallet = new MyWallet(94700);

        String nombre;

        System.out.println("Bienvenido a su sistema de gestión financiera");
        System.out.println("Ingrese su nombre");
        nombre = scanner.next();
        System.out.println("Te damos la bienvenida " + nombre);

        int op;
        do {
            System.out.println("Seleccione una opción:");
            System.out.println("1. Ver Saldo");
            System.out.println("2. Abonar dinero");
            System.out.println("3. Retirar dinero");
            System.out.println("4. Convertir saldo a USD");
            System.out.println("5. Salir");
            op = scanner.nextInt();

            switch (op) {
                case 1:
                    System.out.println("Su saldo en CLP actual es: $" + myWallet.getSaldo());
                    break;
                case 2:
                    System.out.print("Ingrese la cantidad a abonar: $");
                    double abono = scanner.nextDouble();
                    myWallet.abonar(abono);
                    break;
                case 3:
                    System.out.print("Ingrese la cantidad a retirar: $");
                    double retiro = scanner.nextDouble();
                    myWallet.retirar(retiro);
                    break;
                case 4:
                    myWallet.convertir();
                    break;
                case 5:
                    System.out.println("Gracias por usar nuestro servicio.");
                    break;
                default:
                    System.out.println("Opción inválida. Por favor, seleccione nuevamente.");
            }
        } while (op != 5);
    }
}