package WalletTest;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

import Wallet.MyWallet;

public class MyWalletTest {

    @Test
    public void testAbonar() {
        MyWallet myWallet = new MyWallet(1000);
        double cantidadAbonar = 500;
        myWallet.abonar(cantidadAbonar);
        assertEquals(1500, myWallet.getSaldo(), 0);
    }

    @Test
    public void testRetirarConSaldoSuficiente() {
        MyWallet myWallet = new MyWallet(1000);
        double cantidadRetirar = 500;
        myWallet.retirar(cantidadRetirar);
        assertEquals(500, myWallet.getSaldo(), 0);
    }

    @Test
    public void testRetirarConSaldoInsuficiente() {
        MyWallet myWallet = new MyWallet(1000);
        double cantidadRetirar = 1500;
        myWallet.retirar(cantidadRetirar);
        assertEquals(1000, myWallet.getSaldo(), 0);
    }

    @Test
    public void testConvertir() {
        MyWallet wallet = new MyWallet(1000);
        wallet.convertir();
        assertEquals(1000, wallet.getSaldo(), 0.001);
    }
}

